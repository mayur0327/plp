package com.capstore.rest;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.entity.CouponInfo;
import com.capstore.service.CouponService;

@RestController
public class CouponController {

	@Autowired
	private CouponService sobj;

	@PostMapping(path = "/generate", consumes = "application/json")
	public CouponInfo generateCOupon(@RequestBody CouponInfo cobj) throws ParseException {

		// CouponInfo cobj = new CouponInfo();

		return sobj.couponGenerate(cobj);

	}

}
