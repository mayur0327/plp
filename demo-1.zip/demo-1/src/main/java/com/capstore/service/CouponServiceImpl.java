package com.capstore.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capstore.entity.CouponInfo;
import com.capstore.repo.CouponRepo;

@Repository
@Transactional
public class CouponServiceImpl implements CouponService {

	private static int counter = 10000;
	
	@Autowired
	private CouponRepo repo;

	@Override
	public CouponInfo couponGenerate(CouponInfo c) {

		c.setCouponId(counter);
		counter++;
		return repo.save(c);

	}

	@Override
	public String sendCoupon() {
		// TODO Auto-generated method stub
		return null;
	}

}
